package com.mycompany.motherbrain;

import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author willi
 */
public class InputLayer {
    private ArrayList<Input> inputs;

    public InputLayer(ArrayList<Input> inputs) {
        this.inputs = inputs;
    }

    public ArrayList<Input> getInputs() {
        return inputs;
    }
    
    
}
